import mongoose, { Schema } from "mongoose";

const assignmentSchema = new Schema(
  {
    AssignmentName: {
      type: String,
      required: true,
    },
    dueDate: {
      type: Date,
      required: true,
    },
    isCompleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

export const Assignment = mongoose.model("Assignment", assignmentSchema);
