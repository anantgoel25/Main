import { Router } from "express";
import { GetTodoData, AddTodo, AddAssignment, ToggleCompletion } from "../Controllers/todo.controller.js";

const router = Router();

// Existing routes
router.route("/get-all-todos").get(GetTodoData);
router.route("/create-new-todo").post(AddTodo);
router.route("/create-new-assignments").post(AddAssignment);

// New route for toggling completion
router.route("/toggle-completion").post(ToggleCompletion);

export default router;
