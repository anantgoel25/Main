import { Todo } from "../Models/todo.model.js";
import { Assignment } from "../Models/assignments.model.js";

// Fetching data for todos and assignments
export const GetTodoData = async (req, res) => {
  try {
    const allTodos = await Todo.find(); // Fetch all todos
    const allAssignments = await Assignment.find(); // Fetch all assignments
    return res.status(200).json({ allTodos, allAssignments }); // Send both in response
  } catch (error) {
    console.error("Error fetching todo data:", error);
    return res.status(500).json({ message: "Failed to fetch todo data" });
  }
};

// Adding a new todo
export const AddTodo = async (req, res) => {
  try {
    const { taskName, dueDate, isCompleted } = req.body;

    // Validate required fields
    if (!taskName || !dueDate) {
      return res.status(400).json({ message: "Task name and due date are required" });
    }

    // Create and save the todo
    const newTodo = new Todo({
      taskName,
      dueDate,
      isCompleted: isCompleted || false, // Default to false if not provided
    });
    const savedTodo = await newTodo.save();
    return res.status(201).json(savedTodo); // Respond with the saved todo
  } catch (error) {
    console.error("Error adding todo:", error);
    return res.status(500).json({ message: "Failed to add todo" });
  }
};

// Adding a new assignment
export const AddAssignment = async (req, res) => {
  try {
    const { AssignmentName, dueDate, isCompleted } = req.body;

    if (!AssignmentName || !dueDate) {
      return res.status(400).json({ message: "Assignment name and due date are required" });
    }

    const newAssignment = new Assignment({
      AssignmentName,
      dueDate,
      isCompleted: isCompleted || false,
    });

    const savedAssignment = await newAssignment.save();
    return res.status(201).json(savedAssignment);
  } catch (error) {
    console.error("Error adding Assignment:", error);
    return res.status(500).json({ message: "Failed to add Assignment" });
  }
};

// Toggling completion for a todo or assignment
export const ToggleCompletion = async (req, res) => {
  try {
    const { id, type } = req.body;

    // Validate the input
    if (!id || !type) {
      return res.status(400).json({ message: "ID and type (todo or assignment) are required" });
    }

    // Dynamically select the model based on type (todo or assignment)
    const Model = type === "todo" ? Todo : type === "assignment" ? Assignment : null;

    if (!Model) {
      return res.status(400).json({ message: "Invalid type provided. Valid types are 'todo' or 'assignment'" });
    }

    // Find the item in the database
    const item = await Model.findById(id);
    if (!item) {
      return res.status(404).json({ message: "Item not found" });
    }

    // Toggle completion status
    item.isCompleted = !item.isCompleted;
    await item.save();

    // If item is marked as completed, delete it after 30 seconds
    if (item.isCompleted) {
      setTimeout(async () => {
        try {
          const latestItem = await Model.findById(id);
          if (latestItem && latestItem.isCompleted) {
            await Model.findByIdAndDelete(id);
            console.log(`${type} with ID ${id} has been deleted.`);
          }
        } catch (error) {
          console.error(`Error deleting ${type} after 30 seconds:`, error);
        }
      }, 30000); // 30 seconds
    }

    return res.status(200).json({ message: `${type} updated successfully`, item });
  } catch (error) {
    console.error("Error toggling completion:", error);
    return res.status(500).json({ message: "Failed to toggle completion" });
  }
};
