import express from "express";
import cors from "cors";
// import cookieParser from "cookie-parser"
import TodoRoutes from "../src/Routes/todo.routes.js";  // Ensure the path is correct for your routes

const app = express();

// Middleware
app.use(express.json());
app.use(cors({
    origin: process.env.CORS_ORIGIN,
    credentials: true
}));

// app.use(express.json({limit: "16kb"}))
// app.use(express.urlencoded({extended: true, limit: "16kb"}))
// app.use(express.static("public"))
// app.use(cookieParser())

// Routes import
app.get("/", (req, res) => {
  res.send("Hello World!");
});

// Routes declaration
app.use("/api/v1/todo", TodoRoutes);  // Existing route for todo

export { app };
